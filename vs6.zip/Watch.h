#pragma once
#include "afxwin.h"
#include <map>
#include "MyListCtrl.h"

// CWatch ��ȭ �����Դϴ�.

enum OutputType {
	OUTPUT_INTEGER = 0,
	OUTPUT_OPCODE,
	OUTPUT_FLOAT,
	OUTPUT_DOUBLE,
	OUTPUT_STRING,
	OUTPUT_AOB
};

enum IntShowType {
	OUTPUT_DEC_SIGNED = 0,
	OUTPUT_DEC_UNSIGNED,
	OUTPUT_HEX
};

enum StrShowType {
	OUTPUT_ANSI = 0,
	OUTPUT_UTF8,
	OUTPUT_UTF16
};

class CWatch : public CDialog
{
	DECLARE_DYNAMIC(CWatch)

public:
	CWatch(PVOID pAddress, CWnd* pParent = NULL);
	virtual ~CWatch();

	// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_WATCH };

	PVOID m_pAddress;
	BOOL m_bCapture;
	OutputType m_nType;
	IntShowType m_nIntShowType;
	StrShowType m_nStrShowType;

	BOOL m_bRect;
	CRect m_DlgRect;
	CRect m_ListRect;

	CString m_szExp;
	CString m_szLen;

	HACCEL m_hAccel;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	DECLARE_MESSAGE_MAP()
public:
	void AddItem(CONTEXT& ctx);

	afx_msg void OnBnClickedButtonState();
	virtual BOOL OnInitDialog();
	CButton m_btnState;
	afx_msg void OnBnClickedButtonClear();
	CMyListCtrl m_listLog;
	CEdit m_editExp;
	CComboBox m_comboType;
	CEdit m_editLen;
	CButton m_radioOpt1;
	CButton m_radioOpt2;
	CButton m_radioOpt3;
	afx_msg void OnBnClickedRadioOpt1();
	CStatic m_staticLen;
	afx_msg void OnCbnSelchangeComboType();
	afx_msg void OnBnClickedRadioOpt2();
	afx_msg void OnBnClickedRadioOpt3();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnSizing(UINT fwSide, LPRECT pRect);
	afx_msg void OnGetMinMaxInfo(MINMAXINFO* lpMMI);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnAcceleratorCtrlT();
	afx_msg void OnAcceleratorCtrlL();
};
