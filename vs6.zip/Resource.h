//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// Honoka.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDC_BUTTON_STATE                1000
#define IDC_LIST_LOG                    1001
#define IDC_BUTTON_STATE2               1002
#define IDC_BUTTON_CLEAR                1002
#define IDC_EDIT_EXPRESSION             1004
#define IDR_ACCELERATOR1                1004
#define IDC_COMBO_TYPE                  1005
#define IDR_ACCELERATOR2                1005
#define IDC_RADIO_OPT1                  1006
#define IDD_WATCH                       1007
#define IDC_RADIO_OPT2                  1007
#define IDC_RADIO_OPT3                  1008
#define IDC_EDIT_LENGTH                 1009
#define IDC_STATIC_LENGTH               1010
#define IDC_CHECK_OPT2                  1012
#define ID_ONITEM_DELETE                32773
#define ID_ONLIST_CLEARLIST             32776
#define ID_ACCELERATOR_CTRL_A           32796
#define ID_ACCELERATOR_CTRL_C           32797
#define ID_ACCELERATOR_CTRL_G           32798
#define ID_ACCELERATOR_CTRL_R           32799
#define ID_ACCELERATOR32800             32800
#define ID_ACCELERATOR_CTRL_T           32800
#define ID_ACCELERATOR_CTRL_L           32806
#define ID_ACCELERATOR32808             32808

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1006
#define _APS_NEXT_COMMAND_VALUE         32810
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           1008
#endif
#endif
